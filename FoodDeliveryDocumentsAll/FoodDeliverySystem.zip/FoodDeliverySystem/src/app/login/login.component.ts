import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  credantial={'username':'','password':''};
  errorMessage="";
  private loggedIn=false;
  constructor(private loginService:LoginService,private router:Router) { }

  login(){
    // this.loginService.checkCredantial(this.credantial.username,this.credantial.password).subscribe(
    //   res=>{
    //     console.log('login success');
    //   },
    //   error=>{
    //     console.log(error);
    //   }
    // );
    // console.log(this.credantial);
    // if (this.credantial.username == "admin@gmail.com" && this.credantial.password == "admin") {
    //   this.router.navigate(['adminhome']);
    // }else if (this.credantial.username == "customer@gmail.com" && this.credantial.password == "customer") {
    //   this.router.navigate(['customerhome']);
    // }else if (this.credantial.username == "restaurant@gmail.com" && this.credantial.password == "restaurant") {
    //   this.router.navigate(['restauranthome']);
    // }else {
    //   this.errorMessage = "username/password is wrong";
    // }
  }
  ngOnInit() {
  }

}
