import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-addrestaurant',
  templateUrl: './addrestaurant.component.html',
  styleUrls: ['./addrestaurant.component.css']
})
export class AddrestaurantComponent implements OnInit {

 
    userObj={
      "restaurantName":"",
      "restaurantAddress":"",
      "restaurantEmail":"",
      // "adminId":""
      }

      admId:any;
    constructor(private route: ActivatedRoute,private dataservice:DataService,
      private router: Router) { }

  ngOnInit() {
  }

  RegisterRestaurant(){
    console.log(this.userObj);
    this.admId=localStorage.getItem('adminId');
    console.log('adddd'+this.admId);
    //let observable=this.dataservice.addRestaurant(this.userObj,this.userObj.adminId);
    let observable=this.dataservice.addRestaurant(this.userObj,this.admId);
    observable.subscribe((result)=>{

      alert(JSON.stringify(result));
      console.log(result)
      this.router.navigate(['/adminhome']);

    })
  }
}
