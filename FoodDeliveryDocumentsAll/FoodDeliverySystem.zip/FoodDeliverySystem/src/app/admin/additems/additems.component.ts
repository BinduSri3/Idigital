import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-additems',
  templateUrl: './additems.component.html',
  styleUrls: ['./additems.component.css']
})
export class AdditemsComponent implements OnInit {

  userObj = {
    "itemname": "",
    "itemdescription": "",
    "itemPrice": "",
    "restaurantId":""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }


  ngOnInit() {
  }

  AddItems() {
    console.log(this.userObj);
    //var restaurantId =2;
    let observable = this.dataservice.addFoodItems(this.userObj, this.userObj.restaurantId);
    observable.subscribe((result) => {
      alert(JSON.stringify(result));
      console.log(result)
      this.router.navigate(['/adminhome']);
    })
  }

}
