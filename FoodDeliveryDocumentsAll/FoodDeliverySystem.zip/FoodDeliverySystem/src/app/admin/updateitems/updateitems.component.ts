import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-updateitems',
  templateUrl: './updateitems.component.html',
  styleUrls: ['./updateitems.component.css']
})
export class UpdateitemsComponent implements OnInit {

  user: any;

  userObj = {
    "itemname": "",
    "itemdescription": "",
    "itemPrice": "",
    //"itemId":"",

  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let observableresult = this.dataservice.getFoodItemsbyId(localStorage.getItem("id"));
     observableresult.subscribe((result) => {
       console.log(result);
       this.user = result;
     })
  }

  UpdateItem() {
  
    //let oberservableresult = this.dataservice.updateItems(this.user, this.user.itemId);
    //let oberservableresult = this.dataservice.updateItems(this.userObj, this.userObj.itemId);
    let oberservableresult = this.dataservice.updateItems(this.userObj, localStorage.getItem('id'));
    oberservableresult.subscribe((result) => {
      console.log(result);
      alert("item updated with "+JSON.stringify(result));
      this.router.navigate(['/listallitems']);
    })
  }
}

