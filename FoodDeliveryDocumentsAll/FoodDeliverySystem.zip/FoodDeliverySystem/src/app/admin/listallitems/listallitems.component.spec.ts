import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListallitemsComponent } from './listallitems.component';

describe('ListallitemsComponent', () => {
  let component: ListallitemsComponent;
  let fixture: ComponentFixture<ListallitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListallitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListallitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
