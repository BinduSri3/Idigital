import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-listallitems',
  templateUrl: './listallitems.component.html',
  styleUrls: ['./listallitems.component.css']
})
export class ListallitemsComponent implements OnInit {




  itemlist:any;
  items={
    "itemId":"",
    "itemname": "",
    "itemdescription": "",
    "itemPrice":""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getFoodItems();
    oberservableresult.subscribe((result) => {
      console.log(result); this.itemlist = result;
    })
  }
  DeleteItem(itemId){
    const res = confirm("Are you sure want to delete item with ID : " + itemId);
    if (res == true) {
      this.dataservice.deleteItems(itemId).subscribe((result) => {
        this.router.navigate(['/adminhome']);
      })
    }
  }


  Update(itemId){
    debugger;
    localStorage.setItem("id",itemId);
    this.router.navigate(['/updateitems']);
  }
}
