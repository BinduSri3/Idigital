import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
import { debug } from 'util';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  orderAmount: any;
  customerId: any;
  responseOrderId: any
  // paymentList:any;
  orderObj = {
    "orderDate": "",
    "orderTotalAmount": ""
  }
  ordObj = {
    "orderId": "",
    "orderDate": "",
    "orderTotalAmount": ""
  }
  paymentObj = {
    "cardNumber": "",
    "expirationDate": "",
    "cvCode": "",
    "cardOwner": ""
  }
  res: any;
  //registerForm: FormGroup;
  //submitted = false;

  constructor(private formBuilder: FormBuilder,private router: Router, private dataservice: DataService) { }
  ngOnInit() {

    // this.registerForm = this.formBuilder.group({
    //   cardNumber: ['', Validators.required],
    //   expirationDate: ['', Validators.required],
    //   cvCode: ['', [Validators.required]],
    //   cardOwner: ['', Validators.required],
    // })
  }
  //get f() { return this.registerForm.controls; }





  // orderPlaced() {

  //   this.orderObj.orderDate = formatDate(new Date(), 'dd/MM/yyyy', 'en');
  //   this.orderObj.orderTotalAmount = JSON.parse(localStorage.getItem('orderAmount'));
  //   this.customerId = JSON.parse(localStorage.getItem('custId'));

  //   console.log(this.customerId);
  //   let observableresult = this.dataservice.addOrder(this.orderObj, this.customerId);
  //   observableresult.subscribe((result) => {
  //     debugger;
  //     this.ordObj.orderId = result['orderId'];
  //     this.ordObj.orderDate = result['orderDate'];
  //     this.ordObj.orderTotalAmount = result['orderTotalAmount'];

  //     localStorage.setItem('orderDetails', JSON.stringify(this.orderObj));
  //     this.responseOrderId = result;


  //     this.paymentObj.paymentDate = formatDate(new Date(), 'dd/MM/yyyy', 'en');
  //     this.paymentObj.paymentPrice = this.orderObj.orderTotalAmount;
  //     console.log("pay"+JSON.stringify(this.paymentObj));
  //     this.router.navigate(['/customerhome']);
  //     // let observable = this.dataservice.addPayment(JSON.stringify(this.paymentObj), this.responseOrderId['orderId']);

  //     // observable.subscribe((response) => {
  //     //   this.res = response;
  //     //   alert('Payment Successful.., Order Placed:-)');
  //     //   this.router.navigate(['/customerhome']);
  //     // }, (error) => {
  //     //   console.log(error);
  //     // });
  //   });
  // }


  paymentDone() {

    // debugger;
    // this.submitted = true;

    // if (this.registerForm.invalid) {
    //   return;
    // }

    this.orderObj.orderDate = formatDate(new Date(), 'dd/MM/yyyy', 'en');
    this.orderObj.orderTotalAmount = JSON.parse(localStorage.getItem('orderAmount'));
    this.customerId = JSON.parse(localStorage.getItem('custId'));

    console.log(this.customerId);
    let observableresult = this.dataservice.addOrder(this.orderObj, this.customerId);
    observableresult.subscribe((result) => {
      debugger;

      this.ordObj.orderId = result['orderId'];
      this.ordObj.orderDate = result['orderDate'];
      this.ordObj.orderTotalAmount = result['orderTotalAmount'];

      localStorage.setItem('orderDetails', JSON.stringify(this.orderObj));

      //this.paymentObj.paymentDate = formatDate(new Date(), 'dd/MM/yyyy', 'en');
      //this.paymentObj.paymentPrice = this.orderObj.orderTotalAmount;

      this.responseOrderId = result;
      console.log('addded succesfull');
      let observable = this.dataservice.addPayment(this.paymentObj, this.responseOrderId['orderId']);
      observable.subscribe((det) => {
        alert('Payment Successful.., Order Placed:-)' + JSON.stringify(det));
        this.router.navigate(['/customerhome']);
      });
    })
  }
  // onReset() {
  //   this.submitted = false;
  //   this.registerForm.reset();
  //   this.router.navigate(['']);
  // }
}