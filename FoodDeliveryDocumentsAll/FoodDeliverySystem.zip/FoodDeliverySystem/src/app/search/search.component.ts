import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  Restaurantlist: any;
  Restaurant = {
    "restaurantId": "",
    "restaurantName": "",
    "restaurantAddress": "",
    "restaurantEmail": "",
    "restaurantItems": ""
  }
  searchObj={
    "restroName":""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    this.searchObj.restroName=localStorage.getItem('searchName');
    let oberservableresult = this.dataservice.searchRestro(this.searchObj);
    oberservableresult.subscribe((result) => {
    console.log(result); this.Restaurantlist = result;
    })
  }
}
