import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {

  cust: any;
  credantial = { 'custusername': '', 'custpassword': '' };
  errorMessage = "";
  private loggedIn = false;

  // registerForm: FormGroup;
  // submitted = false;

  constructor(private formBuilder: FormBuilder, private loginService: LoginService, private router: Router,
    private dataservice: DataService) { }

  ngOnInit() {
    // this.registerForm = this.formBuilder.group({
    //   custusername: ['', Validators.required],
    //   custpassword: ['', [Validators.required, Validators.minLength(6)]],
    // })
  }
  //get f() { return this.registerForm.controls; }

  loginCustomer() {

    // this.submitted = true;
    // if (this.registerForm.invalid) {
    //   return;
    // }

    let observableResult = this.dataservice.loginCustomer(this.credantial);
    observableResult.subscribe((result) => {
      debugger;
      this.cust = result;
      console.log(this.cust);
      console.log(this.cust[0].customerId);
      localStorage.setItem('custId', this.cust[0].customerId);

      
      if (this.credantial.custusername == this.cust[0].firstName && this.credantial.custpassword == this.cust[0].customerPassword) {
        this.router.navigate(['/customerhome']);
      }
      else {
        this.errorMessage = "username/password incorrect";
      }
    })
  }
  //}
}
