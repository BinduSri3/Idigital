import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-restaurantitems',
  templateUrl: './restaurantitems.component.html',
  styleUrls: ['./restaurantitems.component.css']
})
export class RestaurantitemsComponent implements OnInit {

  itemlist: any;
  items = {
    "itemId":"",
    "itemname": "",
    "itemdescription": "",
    "itemPrice": ""
  }

  product: any;
  prodlist = new Array();

 
  cart: any = JSON.parse(localStorage.getItem('cart'));

  allproducts: any = [];

  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getFoodItems();
    //let oberservableresult = this.dataservice.getFoodItems(restaurantId);
    oberservableresult.subscribe((result) => {
      console.log(result); 
      this.itemlist = result;

      this.route.paramMap.subscribe((result) => { //from url
        var No = result.get("vid");
        localStorage.setItem("vid", No);
        let observableResult = this.dataservice.getFoodItems();//send to db and get result
        observableResult.subscribe((data) => { //db result on data 
          //this.allproducts = data;
          this.itemlist=data;
          //add data in all products array
          // console.log(this.product.pId);
        })
      })
    })
  }

  addtoCart(pid) {
    console.log(pid);
    console.log("list of all products" +  JSON.stringify(this.itemlist));
    let status = this.findprodbyid(pid);
    if (status > 0) {
      alert("product added in cart successfully")
      console.log("cart details are")
      console.log(this.cart);
    }
  }

  private findprodbyid(id: string) {
    for (var i = 0; i < this.itemlist.length; i++) {
      if (this.itemlist[i].itemId == id) {
        this.items=this.itemlist[i];
        this.cart.push(this.items);
        localStorage.setItem('cart', JSON.stringify(this.cart));
        console.log(this.cart);
        return this.itemlist[i].itemId;
      }
    }
    return -1;
  }
  logoutCustomer() {
    const res = confirm("Are you sure want to logout??");
    if (res == true) {
      debugger;
      localStorage.removeItem('custId');
      localStorage.removeItem('orderAmount');
      localStorage.removeItem('amount');
      localStorage.removeItem('cartlength');
      this.router.navigate(['/customerlogin']);
    }
  }

}
