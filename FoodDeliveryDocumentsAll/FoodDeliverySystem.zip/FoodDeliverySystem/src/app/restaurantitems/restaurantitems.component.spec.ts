import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantitemsComponent } from './restaurantitems.component';

describe('RestaurantitemsComponent', () => {
  let component: RestaurantitemsComponent;
  let fixture: ComponentFixture<RestaurantitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
