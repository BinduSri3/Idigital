import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  paymentObj = {
    "cardNumber": "",
    "expirationDate": "",
    "cvCode": "",
    "cardOwner": ""
  }
  paymentList: any;
  orderList: any;
  order = {

    "orderDate": "",
    "orderTotalAmount": ""
  }
  customerId: any;
  constructor(private router: Router, private dataservice: DataService) { }

  ngOnInit() {


    this.orderList = JSON.parse(localStorage.getItem('orderDetails'));

    let oberservableresult = this.dataservice.getPayDetails();
    oberservableresult.subscribe((res)=>{
      this.paymentList=res;
      console.log(this.paymentList);
    });


    // let oberservableresult = this.dataservice.getFoodItems();
    // oberservableresult.subscribe((result) => {
    //   console.log(result);
    //   this.orderList = result;
    // })
    //console.log("ordered");
    //console.log(localStorage.getItem('orderDetails'));


    // debugger;
    // this.customerId=localStorage.getItem('custId');
    // let oberservableresult=this.dataservice.getAllOrders(JSON.stringify(this.customerId));
    // oberservableresult.subscribe((result)=>{
    //   console.log('ggg'+result);
    //   this.orderList=result;
    //   console.log('insideorder'+this.orderList);
    // });
    //console.log(this.orderList+'gotit');
   

  }
}
