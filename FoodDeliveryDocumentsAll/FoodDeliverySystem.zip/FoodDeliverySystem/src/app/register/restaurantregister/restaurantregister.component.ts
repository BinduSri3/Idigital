import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-restaurantregister',
  templateUrl: './restaurantregister.component.html',
  styleUrls: ['./restaurantregister.component.css']
})
export class RestaurantregisterComponent implements OnInit {

  userObj={
    "restaurantName":"",
    "restaurantAddress":"",
    "restaurantEmail":"",
    "adminId":""
    }
  constructor(private route: ActivatedRoute,private dataservice:DataService,
    private router: Router) { }

  ngOnInit() {
  }

  RegisterRestaurant(){
    console.log(this.userObj);
    let observable=this.dataservice.addRestaurant(this.userObj,this.userObj.adminId);
    observable.subscribe((result)=>{

      alert(JSON.stringify(result));
      console.log(result)
      this.router.navigate(['/restauranthome']);

    })
  }

}
