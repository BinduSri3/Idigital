import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  userObj = { "adminUsername": "", "adminPassword": "" };
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, 
    private dataservice: DataService,private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      adminUsername: ['', Validators.required],
      adminPassword: ['', [Validators.required, Validators.minLength(6)]],
    })
  }

  get f() { return this.registerForm.controls; }
  RegisterAdmin() {

    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    let observable = this.dataservice.addAdmin(this.registerForm.value);
    observable.subscribe((result) => {
      alert(JSON.stringify(result));
      this.router.navigate(['/adminlogin']);
    })

  }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
    this.router.navigate(['']);

  }
}
