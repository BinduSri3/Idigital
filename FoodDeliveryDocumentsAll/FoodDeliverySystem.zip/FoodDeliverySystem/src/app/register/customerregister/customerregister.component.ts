import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {


  cust =
    {
      "firstName": "",
      "lastName": "",
      "custEmailId": "",
      "custAddress": "",
      "custmobileNumber": "",
      "customerPassword": "",
    }
  registerForm: FormGroup;
  submitted = false;
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      custEmailId: ['', [Validators.required, Validators.email]],
      custAddress: ['', Validators.required],
      custmobileNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      customerPassword: ['', [Validators.required, Validators.minLength(6)]],
    })
  }
  get f() { return this.registerForm.controls; }
  RegisterCustomer() {

    this.submitted = true;

    if (this.registerForm.invalid) {
      return;
    }
    let observable = this.dataservice.addCustomer(this.registerForm.value);

    observable.subscribe((result) => {
      alert(JSON.stringify(result));
    });
    this.router.navigate(['/customerlogin']);
  }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
    this.router.navigate(['']);
  }
}
