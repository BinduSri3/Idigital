import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DataService {



  private url = "http://localhost:8022/FoodManagement/";
  
  constructor(private http: HttpClient, private router: Router) { }


  loginAdmin(credantial) {
    return this.http.get(this.url + 'loginadmin?adminUsername=' +
      credantial.username + '&adminPassword=' + credantial.password);
  }

  loginCustomer(credantial) {
    return this.http.get(this.url + 'logincustomer?firstName=' +
      credantial.custusername + '&customerPassword=' + credantial.custpassword);
  }

  addAdmin(userObj: { adminUsername: string; adminPassword: string; }) {
    return this.http.post(this.url + "addadmin", userObj);
  }

  addCustomer(cust) {
    return this.http.post(this.url + "registerCustomer", cust);

  }

  addRestaurant(userObj, adminId) {
    return this.http.post(this.url + "addRestaurant/" + adminId, userObj);
  }

  getAdmins() {
    return this.http.get(this.url + 'getAdmins');
  }


  getallrestaurants() {
    return this.http.get(this.url + "getRestaurants");

  }
  getrestaurantbyId(restaurantId) {
    return this.http.get(this.url + "getRestaurant/" + restaurantId);
  }

 searchRestro(restroName)
 {
   return this.http.get(this.url+'restaurantSearch/'+restroName);
 }
  addFoodItems(userobj, restaurantId) {
    return this.http.post(this.url + "addFoodItems/" + restaurantId, userobj);
  }
  getFoodItems() {
    return this.http.get(this.url + "getFoodItems");
  }
  getFoodItemsbyId(itemId) {
    return this.http.get(this.url + "getFoodItems/" + itemId);
  }

  // getFoodItemsbyId(itemId) {
  //   return this.http.get(this.url + "restaurantItems/"+itemId);
  // }
  deleteItems(itemId) {
    return this.http.delete(this.url + 'restaurantItems/' + itemId);
  }

  updateItems(itemObj, itemId) {
    return this.http.put(this.url + 'restaurantItems/' + itemId, itemObj);
  }

  addOrder(orderObj, customerId) {
    return this.http.post(this.url + 'addorder/' + customerId, orderObj);
  }
  getAllOrders(customerId) {
    debugger;
    console.log(this.url + 'getOrders/' + customerId);
    return this.http.get(this.url + 'getOrders/' + customerId);
  }

  deleteOrder(orderId) {
    return this.http.delete(this.url + 'orders/' + orderId);
  }

  updateOrders(orderObj, orderId) {
    return this.http.post(this.url + 'order/' + orderId, orderObj);
  }

  addPayment(paymentObj, orderId) {
    debugger;
    console.log(this.url + 'payment/' + orderId);
    return this.http.post(this.url + 'payment/' + orderId, paymentObj);
  }

  getPayDetails() {
    return this.http.get(this.url+'getPaymentDetails');
  }
}
