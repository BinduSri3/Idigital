import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {



  admin: any;
  credantial = { 'username': '', 'password': '' };
  errorMessage = "";
  private loggedIn = false;
  constructor(private loginService: LoginService, private router: Router,
    private dataservice: DataService) { }

  ngOnInit() {
  }
  loginAdmin() {
    
    let observableResult = this.dataservice.loginAdmin(this.credantial);
    observableResult.subscribe((result) => {
      console.log("hello" + (JSON.stringify(result)));
      this.admin = result;
      localStorage.setItem('adminId',this.admin[0].adminId);
      if(this.credantial.username.length==0 && this.credantial.password.length==0)
      {
        this.errorMessage = "Enter username/password ";
      }
      else if (this.credantial.username == this.admin[0].adminUsername && this.credantial.password == this.admin[0].adminPassword) {
        this.router.navigate(['/adminhome']);
      }
      else {
        this.errorMessage = "username/password incorrect";
      }
    })
  }
}

