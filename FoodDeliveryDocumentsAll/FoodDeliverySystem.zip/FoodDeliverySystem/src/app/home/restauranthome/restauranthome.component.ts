import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-restauranthome',
  templateUrl: './restauranthome.component.html',
  styleUrls: ['./restauranthome.component.css']
})
export class RestauranthomeComponent implements OnInit {

  itemlist:any;
  items={
    "itemname": "",
    "itemdescription": "",
    "itemPrice":""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getFoodItems();
    oberservableresult.subscribe((result) => {
      console.log(result); this.itemlist = result;
    })
  }
  logoutOwner(){
    this.router.navigate(['/restauranthome']);
  }
}
