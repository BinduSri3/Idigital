import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-customerhome',
  templateUrl: './customerhome.component.html',
  styleUrls: ['./customerhome.component.css']
})
export class CustomerhomeComponent implements OnInit {

  Restaurantlist: any;
  Restaurant1: any;
  Restaurant = {
    "restaurantId": "",
    "restaurantName": "",
    "restaurantAddress": "",
    "restaurantEmail": "",
    "restaurantItems": ""
  }

  cart: any = [];
  length: number = JSON.parse(localStorage.getItem('cartlength'));
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getallrestaurants();
    oberservableresult.subscribe((result) => {
      console.log(result); this.Restaurantlist = result;
      localStorage.setItem('cart', JSON.stringify(this.cart));
    })

  }


  
  // resbyId(restaurantId) {
  //   let oberservableresult = this.dataservice.getrestaurantbyId(restaurantId);
  //   oberservableresult.subscribe((result) => {
  //     console.log(result);
  //     this.Restaurant1 = result;
  //     this.router.navigate(['/restaurantitems']);
  //   })
  // }

  GetItems() {
    let oberservableresult = this.dataservice.getFoodItems();
    oberservableresult.subscribe((result) => {
      console.log(result);
      this.Restaurant1 = result;
      this.router.navigate(['/restaurantitems']);
    })
  }

  logoutCustomer() {
    const res = confirm("Are you sure want to logout??");
    if (res == true) {
      localStorage.removeItem('custId');
      localStorage.removeItem('orderAmount');
      localStorage.removeItem('amount');
      localStorage.removeItem('cartlength');
      localStorage.removeItem('orderDetails');
      this.router.navigate(['/customerlogin']);
    }
  }
}
