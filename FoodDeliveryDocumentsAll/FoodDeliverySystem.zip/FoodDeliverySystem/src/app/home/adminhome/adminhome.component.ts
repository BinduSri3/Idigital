import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  public height=false;
  
  Restaurantlist: any;
  Restaurant1: any;
  Restaurant = {
    "restaurantId": "",
    "restaurantName": "",
    "restaurantAddress": "",
    "restaurantEmail": "",
    "restaurantItems": ""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    this.height=true;
    let oberservableresult = this.dataservice.getallrestaurants();
    oberservableresult.subscribe((result) => {
      console.log(result); this.Restaurantlist = result;
      
    })
  }
  resbyId(restaurantId) {
    let oberservableresult = this.dataservice.getrestaurantbyId(restaurantId);
    oberservableresult.subscribe((result) => {
      console.log(result);
      this.Restaurant1 = result;
      //localStorage.setItem('restId',this.Restaurant1.restaurantId);
      this.router.navigate(['/restaurantitems']);
    })
  }
  logoutAdmin() {
    const res = confirm("Are you sure want to logout??");
    if (res == true) {
      localStorage.removeItem('adminId');
      this.router.navigate(['/adminlogin']);
    }
  }
}

