import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

    //name:any;
  ngOnInit() {
  }

  //restroList:any;
  //restroObj:{
    //"restroName":""
  //}
  myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  myFunction2() {
    document.getElementById("myDropdown2").classList.toggle("show");
  }
  
  Search(){
    debugger;
    //this.name=localStorage.setItem('searchName',this.restroObj.restroName);
    //console.log('namerestro'+ this.name);
    //this.router.navigate(['/search']);
    // this.name=this.restroObj.restroName;
    // let observable=this.dataservice.searchRestro(this.name);
    // observable.subscribe(res=>{
    //   this.restroList=res;
    //   console.log('afsafa0'+this.restroList);
    //   localStorage.setItem('searchName',this.restroList);
    // })
  }
  // Close the dropdown if the user clicks outside of it
  // window.onclick = function(event) {
  //   if (!event.target.matches('.dropbtn')) {
  //     var dropdowns = document.getElementsByClassName("dropdown-content");
  //     var i;
  //     for (i = 0; i < dropdowns.length; i++) {
  //       var openDropdown = dropdowns[i];
  //       if (openDropdown.classList.contains('show')) {
  //         openDropdown.classList.remove('show');
  //       }
  //     }
  //   }
  // }
}
