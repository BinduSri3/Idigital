import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart: any = [];
  qtymsg: any = [];
  finaltotal: number = 0;
  amount:any;
  prod = new Array;
  bill: any;
  total: any;
  pr: any;
  vid: any;
  pid: any;
  price: any;
  orderlist: any = [];
  quantity:any=1;
  
  constructor(private router: Router, private data: DataService) {
  }
  neworder: any;
  ngOnInit() {
    this.loadcart();
    
  }
  loadcart() {
    this.cart = JSON.parse(localStorage.getItem('cart'));
    for (let i = 0; i < this.cart.length; i++) {
      if (this.cart[i].pqty == "") {
        this.cart[i].pqty = "1";
      }
      //if (this.cart[i].total == "") {
        this.cart[i].total = parseInt(this.cart[i].itemPrice);
        this.finaltotal = this.finaltotal + this.cart[i].itemPrice;
        this.amount=this.finaltotal;
      //}
      localStorage.setItem('orderAmount',this.amount);
      console.log(this.cart[i]);
    }
  }

}
