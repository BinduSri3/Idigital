import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private url='http://localhost:8022/FoodManagement/logincustomer';
  constructor(private http:HttpClient) { }
  checkCredantial(username:string,password:string){
    console.log(this.url);
    return this.http.get(this.url);
  }
}
