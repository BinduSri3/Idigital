import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { AdminregisterComponent } from './register/adminregister/adminregister.component';
import { CustomerregisterComponent } from './register/customerregister/customerregister.component';
import { RestaurantregisterComponent } from './register/restaurantregister/restaurantregister.component';
import { AdminhomeComponent } from './home/adminhome/adminhome.component';
import { CustomerhomeComponent } from './home/customerhome/customerhome.component';
import { RestauranthomeComponent } from './home/restauranthome/restauranthome.component';
import { ListrestaurantsComponent } from './admin/listrestaurants/listrestaurants.component';
import { AddrestaurantComponent } from './admin/addrestaurant/addrestaurant.component';
import { RestaurantitemsComponent } from './restaurantitems/restaurantitems.component';
import { ListitemsComponent } from './restaurant/listitems/listitems.component';
import { CartComponent } from './cart/cart.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { PaymentComponent } from './payment/payment.component';
import { OrdersComponent } from './orders/orders.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdditemsComponent } from './admin/additems/additems.component';
import { UpdateitemsComponent } from './admin/updateitems/updateitems.component';
import { ListallitemsComponent } from './admin/listallitems/listallitems.component';
import { ListrestroComponent } from './restaurant/listrestro/listrestro.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  { path: "", component: HomepageComponent },
  { path: "adminregister", component: AdminregisterComponent },
  { path: "customerregister", component: CustomerregisterComponent },
  { path: "restaurantregister", component: RestaurantregisterComponent },
  { path: "adminhome", component: AdminhomeComponent},
  { path: "customerhome", component: CustomerhomeComponent },
  { path: "restauranthome", component: RestauranthomeComponent },
  { path: "listrestaurants", component: ListrestaurantsComponent},
  { path: "addrestaurant", component: AddrestaurantComponent},
  { path: "restaurantitems", component: RestaurantitemsComponent},
  { path: "listitems", component: ListitemsComponent},
  { path: "cart", component: CartComponent},
  { path: "adminlogin", component: AdminloginComponent},
  { path: "customerlogin", component: CustomerloginComponent},
  { path: "payment", component: PaymentComponent},
  { path: "orders", component: OrdersComponent},
  { path: "contactus", component: ContactusComponent},
  { path: "aboutus", component: AboutusComponent},
  { path: "additems", component: AdditemsComponent},
  { path: "updateitems", component: UpdateitemsComponent},
  { path: "listallitems", component: ListallitemsComponent},
  { path: "listrestro", component: ListrestroComponent},
  { path: "search", component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
