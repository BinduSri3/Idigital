import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-listrestro',
  templateUrl: './listrestro.component.html',
  styleUrls: ['./listrestro.component.css']
})
export class ListrestroComponent implements OnInit {

  Restaurantlist: any;
  Restaurant = {
    "restaurantId": "",
    "restaurantName": "",
    "restaurantAddress": "",
    "restaurantEmail": "",
    "restaurantItems": ""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getallrestaurants();
    oberservableresult.subscribe((result) => {
      console.log(result); this.Restaurantlist = result;

    })
  }

}
