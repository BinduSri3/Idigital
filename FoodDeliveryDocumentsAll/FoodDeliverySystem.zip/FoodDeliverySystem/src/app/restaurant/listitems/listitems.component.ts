import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-listitems',
  templateUrl: './listitems.component.html',
  styleUrls: ['./listitems.component.css']
})
export class ListitemsComponent implements OnInit {

  itemlist:any;
  items={
    "itemname": "",
    "itemdescription": "",
    "itemPrice":""
  }
  constructor(private route: ActivatedRoute, private dataservice: DataService,
    private router: Router) { }

  ngOnInit() {
    let oberservableresult = this.dataservice.getFoodItems();
    oberservableresult.subscribe((result) => {
      console.log(result); this.itemlist = result;
    })
  }
  
}
