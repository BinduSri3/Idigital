import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LoginService } from './service/login.service';
import { HttpClientModule } from '@angular/common/http';
import { NavbarComponent } from './navbar/navbar.component';
import { AdminregisterComponent } from './register/adminregister/adminregister.component';
import { CustomerregisterComponent } from './register/customerregister/customerregister.component';
import { RestaurantregisterComponent } from './register/restaurantregister/restaurantregister.component';
import { AdminhomeComponent } from './home/adminhome/adminhome.component';
import { CustomerhomeComponent } from './home/customerhome/customerhome.component';
import { RestauranthomeComponent } from './home/restauranthome/restauranthome.component';
import { ListrestaurantsComponent } from './admin/listrestaurants/listrestaurants.component';
import { AddrestaurantComponent } from './admin/addrestaurant/addrestaurant.component';
import { ListitemsComponent } from './restaurant/listitems/listitems.component';
import { RestaurantitemsComponent } from './restaurantitems/restaurantitems.component';
import { CartComponent } from './cart/cart.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { OrdersComponent } from './orders/orders.component';
import { PaymentComponent } from './payment/payment.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { UpdateitemsComponent } from './admin/updateitems/updateitems.component';
import { AdditemsComponent } from './admin/additems/additems.component';
import { ListallitemsComponent } from './admin/listallitems/listallitems.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ListrestroComponent } from './restaurant/listrestro/listrestro.component';
import { SearchComponent } from './search/search.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavbarComponent,
    AdminregisterComponent,
    CustomerregisterComponent,
    RestaurantregisterComponent,
    AdminhomeComponent,
    CustomerhomeComponent,
    RestauranthomeComponent,
    ListrestaurantsComponent,
    AddrestaurantComponent,
    ListitemsComponent,
    AdditemsComponent,
    RestaurantitemsComponent,
    CartComponent,
    AdminloginComponent,
    CustomerloginComponent,
    OrdersComponent,
    PaymentComponent,
    AboutusComponent,
    ContactusComponent,
    UpdateitemsComponent,
    ListallitemsComponent,
    HomepageComponent,
    ListrestroComponent,
    SearchComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [
    LoginService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
